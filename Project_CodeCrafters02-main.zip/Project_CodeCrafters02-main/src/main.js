import Accordion from 'accordion-js';

import Swiper from 'swiper';
import 'swiper/css';
import axios from 'axios';

import "./js/header.js"
import './js/about-me.js';
import './js/projects.js';
import '/js/faq.js';
import '/js/covers.js';
import '/js/reviews.js';
import './js/work-together.js'
import './js/scrollup.js'
